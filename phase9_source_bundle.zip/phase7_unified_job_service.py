"""Phase 7 asynchronous, read-only NTFS image scan jobs."""
from __future__ import annotations

import json
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from engine.orchestrator.ntfs_recovery_pipeline import NTFSRecoveryPipeline
from engine.native_cpp.native_bridge import native_status, validate_file_record

ROOT = Path(__file__).resolve().parents[2]
IMAGE_ROOT = (ROOT / "test_images").resolve()
REPORT_ROOT = (ROOT / "reports" / "phase7").resolve()
MAX_IMAGE_BYTES = 16 * 1024 * 1024 * 1024
MAX_RECORDS = 100_000


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class Phase7JobService:
    """Threaded job registry. Source images are read-only; no physical disks."""

    def __init__(self):
        self._lock = threading.RLock()
        self._jobs: dict[str, dict[str, Any]] = {}
        self._cancel: dict[str, threading.Event] = {}
        self._threads: dict[str, threading.Thread] = {}
        REPORT_ROOT.mkdir(parents=True, exist_ok=True)

    def _public(self, job: dict) -> dict:
        # Return a JSON-safe snapshot; omit internal synchronization objects.
        return json.loads(json.dumps(job))

    def create(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            raise ValueError("JSON object required")
        name = payload.get("image")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("image filename is required")
        if name in {".", ".."} or "/" in name or "\\" in name or "\x00" in name:
            raise ValueError("image must be a filename inside test_images")

        source = (IMAGE_ROOT / name).resolve()
        try:
            source.relative_to(IMAGE_ROOT)
        except ValueError:
            raise ValueError("image path is outside test_images") from None
        if source.is_symlink() or not source.is_file():
            raise ValueError("image must be an existing regular file")
        size = source.stat().st_size
        if size <= 0 or size > MAX_IMAGE_BYTES:
            raise ValueError("image size must be between 1 byte and 16 GiB")

        max_records = payload.get("max_records", 100_000)
        if isinstance(max_records, bool) or not isinstance(max_records, int):
            raise ValueError("max_records must be an integer")
        if not 1 <= max_records <= MAX_RECORDS:
            raise ValueError("max_records must be between 1 and 100000")

        job_id = uuid.uuid4().hex
        job = {
            "job_id": job_id,
            "status": "QUEUED",
            "progress": 0,
            "stage": "queued",
            "created_utc": utcnow(),
            "updated_utc": utcnow(),
            "source_name": source.name,
            "source_size_bytes": size,
            "source_sha256": None,
            "pipeline_kind": "read_only_ntfs_scan",
            "evidence_class": "real_image_file",
            "physical_device_access": False,
            "source_modified": False,
            "cancel_requested": False,
            "native": native_status(),
            "result": None,
            "error": None,
        }
        cancel_event = threading.Event()
        with self._lock:
            self._jobs[job_id] = job
            self._cancel[job_id] = cancel_event

        thread = threading.Thread(
            target=self._run,
            args=(job_id, source, max_records),
            name="adr-phase7-" + job_id[:8],
            daemon=True,
        )
        with self._lock:
            self._threads[job_id] = thread
        thread.start()
        return self.get(job_id)

    def get(self, job_id: str) -> dict:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                raise KeyError(job_id)
            return self._public(job)

    def list_jobs(self) -> list[dict]:
        """Return public job snapshots, newest first."""
        with self._lock:
            return [
                self._public(job)
                for job in reversed(tuple(self._jobs.values()))
            ]

    def cancel(self, job_id: str) -> dict:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                raise KeyError(job_id)
            if job["status"] in {"COMPLETED", "FAILED", "CANCELLED"}:
                return self._public(job)
            job["cancel_requested"] = True
            job["updated_utc"] = utcnow()
            self._cancel[job_id].set()
            if job["status"] == "QUEUED":
                job["status"] = "CANCELLED"
                job["stage"] = "cancelled"
                job["updated_utc"] = utcnow()
            return self._public(job)

    def _update(self, job_id: str, **changes) -> None:
        with self._lock:
            job = self._jobs[job_id]
            job.update(changes)
            job["updated_utc"] = utcnow()

    def _check_cancel(self, job_id: str) -> None:
        if self._cancel[job_id].is_set():
            raise InterruptedError("Cancellation requested")

    def _run(self, job_id: str, source: Path, max_records: int) -> None:
        report_path = REPORT_ROOT / (job_id + ".json")
        try:
            # Atomically arbitrate worker start versus queued cancellation.
            with self._lock:
                job = self._jobs.get(job_id)
                if job is None:
                    return
                if job["status"] == "CANCELLED" or self._cancel[job_id].is_set():
                    job["status"] = "CANCELLED"
                    job["stage"] = "cancelled"
                    job["updated_utc"] = utcnow()
                    return
                if job["status"] != "QUEUED":
                    return
                job.update(status="RUNNING", stage="image_inspection", progress=5)
                job["updated_utc"] = utcnow()

            import hashlib
            digest = hashlib.sha256()
            with source.open("rb") as stream:
                while True:
                    self._check_cancel(job_id)
                    chunk = stream.read(1024 * 1024)
                    if not chunk:
                        break
                    digest.update(chunk)
            self._update(job_id, source_sha256=digest.hexdigest(),
                         stage="ntfs_volume_inspection", progress=15)

            self._check_cancel(job_id)
            pipeline = NTFSRecoveryPipeline(source)
            inspection = pipeline.inspect_volume()
            if not inspection.get("passed"):
                raise ValueError(
                    "NTFS image inspection failed: "
                    + str(inspection.get("error", "invalid volume"))
                )

            self._check_cancel(job_id)
            self._update(job_id, stage="mft_discovery", progress=30)
            discovery = pipeline.discover_mft_records(max_records=max_records)
            if not discovery.get("passed"):
                raise ValueError(
                    "MFT discovery failed: "
                    + str(discovery.get("error", "discovery unsuccessful"))
                )

            candidates = discovery.get("candidates", [])
            native_counts = {"native_cpp": 0, "python_fallback": 0,
                             "valid_headers": 0, "invalid_headers": 0}
            checked = []
            total = len(candidates)

            for index, candidate in enumerate(candidates):
                self._check_cancel(job_id)
                try:
                    raw = pipeline.image.read_at(
                        int(candidate["offset"]), int(candidate["record_size"])
                    )
                    verdict = validate_file_record(
                        raw, int(inspection["bytes_per_sector"])
                    )
                    engine = verdict.get("engine", "python_fallback")
                    native_counts[engine] = native_counts.get(engine, 0) + 1
                    if verdict.get("valid"):
                        native_counts["valid_headers"] += 1
                    else:
                        native_counts["invalid_headers"] += 1
                    checked.append({
                        "offset": int(candidate["offset"]),
                        "record_size": int(candidate["record_size"]),
                        "sequence_number": candidate.get("sequence_number"),
                        "flags": candidate.get("flags"),
                        "header_valid": bool(verdict.get("valid")),
                        "validation_code": verdict.get("code"),
                        "validation_engine": engine,
                        "recoverability_proven": False,
                    })
                except Exception as exc:
                    checked.append({
                        "offset": candidate.get("offset"),
                        "header_valid": False,
                        "validation_error": type(exc).__name__,
                        "recoverability_proven": False,
                    })

                if index % 100 == 0:
                    progress = 35 + int(50 * (index + 1) / max(total, 1))
                    self._update(job_id, progress=min(progress, 85),
                                 stage="native_candidate_validation")

            self._check_cancel(job_id)
            result = {
                "pipeline": [
                    "image_hash",
                    "read_only_ntfs_inspection",
                    "mft_candidate_discovery",
                    "native_structural_header_validation",
                    "report",
                ],
                "inspection": inspection,
                "discovery": {
                    "candidate_count": len(candidates),
                    "scope": discovery.get("scope"),
                },
                "native_validation": native_counts,
                "candidates": checked,
                "report_path": str(report_path),
                "recovery_performed": False,
                "deleted_file_reconstruction": "NOT_IMPLEMENTED_IN_THIS_PIPELINE",
                "output_exported": False,
                "source_modified": False,
                "physical_device_access": False,
                "recoverability_proven": False,
                "evidence_class": "real_image_file",
            }
            report = {
                "schema": "adr.phase7.report.v1",
                "job_id": job_id,
                "created_utc": utcnow(),
                "source_name": source.name,
                "source_size_bytes": source.stat().st_size,
                "source_sha256": digest.hexdigest(),
                "result": result,
            }
            temp = report_path.with_suffix(".json.tmp")
            temp.write_text(json.dumps(report, indent=2), encoding="utf-8")
            temp.replace(report_path)
            self._update(job_id, status="COMPLETED", progress=100,
                         stage="completed", result=result)
        except InterruptedError:
            self._update(job_id, status="CANCELLED", stage="cancelled",
                         error="Cancellation requested")
        except Exception as exc:
            self._update(job_id, status="FAILED", stage="failed",
                         error={"type": type(exc).__name__, "message": str(exc)[:500]})
        finally:
            with self._lock:
                self._threads.pop(job_id, None)


SERVICE = Phase7JobService()
