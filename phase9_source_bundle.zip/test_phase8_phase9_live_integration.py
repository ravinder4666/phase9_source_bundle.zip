﻿import json
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen

import adr_api_server
from engine.orchestrator.phase7_unified_job_service import Phase7JobService


ROOT = Path(__file__).resolve().parents[1]


class TestCancellationArbitration(unittest.TestCase):
    def test_queued_cancel_cannot_be_overwritten_by_worker_start(self):
        service = Phase7JobService()
        job_id = "a" * 32
        service._jobs[job_id] = {
            "job_id": job_id,
            "status": "QUEUED",
            "stage": "queued",
            "progress": 0,
            "updated_utc": "",
            "cancel_requested": False,
        }
        service._cancel[job_id] = threading.Event()

        # Cancel wins before the worker obtains its start lock.
        result = service.cancel(job_id)
        self.assertEqual(result["status"], "CANCELLED")

        # The worker must return before touching the source or pipeline.
        service._run(job_id, ROOT / "missing-image.img", 1000)

        final = service.get(job_id)
        self.assertEqual(final["status"], "CANCELLED")
        self.assertEqual(final["stage"], "cancelled")
        self.assertTrue(final["cancel_requested"])


class TestLiveDashboardAPIWorkflow(unittest.TestCase):
    def test_http_scan_poll_and_report_lifecycle(self):
        image_root = ROOT / "test_images"
        image = image_root / "adr_synthetic_ntfs_volume.img"
        if not image.is_file() or image.stat().st_size <= 0:
            self.skipTest("Synthetic NTFS test image is unavailable")

        server = ThreadingHTTPServer(
            ("127.0.0.1", 0), adr_api_server.ADRHandler
        )
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"

        def get_json(path):
            with urlopen(base + path, timeout=5) as response:
                return response.status, json.loads(
                    response.read().decode("utf-8")
                )

        def post_json(path, payload):
            request = Request(
                base + path,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(request, timeout=10) as response:
                return response.status, json.loads(
                    response.read().decode("utf-8")
                )

        try:
            status_code, health = get_json("/api/health")
            self.assertEqual(status_code, 200)
            self.assertTrue(health["ok"])

            status_code, inventory = get_json("/api/images")
            self.assertEqual(status_code, 200)
            self.assertIn(
                image.name, [item["name"] for item in inventory["images"]]
            )

            status_code, created = post_json(
                "/api/scans",
                {"image": image.name, "max_records": 1000},
            )
            self.assertEqual(status_code, 202)
            self.assertTrue(created["ok"])
            job_id = created["job"]["job_id"]
            self.assertRegex(job_id, r"^[a-fA-F0-9]{32}$")

            deadline = time.monotonic() + 45
            job = created["job"]
            while time.monotonic() < deadline:
                status_code, envelope = get_json(f"/api/jobs/{job_id}")
                self.assertEqual(status_code, 200)
                self.assertTrue(envelope["ok"])
                job = envelope["job"]
                if job["status"] in {"COMPLETED", "FAILED", "CANCELLED"}:
                    break
                time.sleep(0.2)
            else:
                self.fail("Scan did not reach a terminal state within 45 seconds")

            if job["status"] == "COMPLETED":
                status_code, report_envelope = get_json(
                    f"/api/jobs/{job_id}/report"
                )
                self.assertEqual(status_code, 200)
                report = report_envelope["report"]
                self.assertEqual(report["job_id"], job_id)
                self.assertEqual(
                    report["source_sha256"], job["source_sha256"]
                )
                self.assertFalse(report["result"]["recovery_performed"])
                self.assertFalse(report["result"]["recoverability_proven"])
            else:
                # A failed/cancelled scan must not expose a completed report.
                request = Request(base + f"/api/jobs/{job_id}/report")
                from urllib.error import HTTPError
                with self.assertRaises(HTTPError) as caught:
                    urlopen(request, timeout=5)
                self.assertEqual(caught.exception.code, 409)

                self.assertNotEqual(
                    job["status"], "RUNNING",
                    "Terminal job unexpectedly remained RUNNING"
                )

            # Recovery capability remains honestly disabled.
            _, capabilities = get_json("/api/capabilities")
            self.assertFalse(capabilities["capabilities"]["live_recovery"])
            self.assertFalse(
                capabilities["capabilities"]["verified_end_to_end_pipeline"]
            )
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
